import SwiftUI

struct ThemesView: View {
    @Environment(AppTheme.self) private var theme
    var body: some View {
        @Bindable var theme = theme
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Text("Themes").font(.system(size: 34, weight: .bold))
                HStack(spacing: 12) {
                    RoundedRectangle(cornerRadius: 14).fill(LinearGradient(colors: theme.preset.colors, startPoint: .topLeading, endPoint: .bottomTrailing)).frame(width: 58, height: 58)
                    VStack(alignment: .leading) { Text("Your current look").font(.headline); Text(theme.preset.rawValue).font(.caption).foregroundStyle(Theme.muted) }
                    Spacer(); Image(systemName: "waveform").foregroundStyle(theme.accent)
                }.padding(14).background(Theme.card, in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(theme.accent, lineWidth: 2))
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                    ForEach(AppTheme.Preset.allCases) { preset in
                        Button { theme.preset = preset } label: {
                            VStack(alignment: .leading, spacing: 10) {
                                RoundedRectangle(cornerRadius: 15).fill(LinearGradient(colors: preset.colors, startPoint: .topLeading, endPoint: .bottomTrailing)).frame(height: 76)
                                HStack { Text(preset.rawValue).font(.headline); Spacer(); if theme.preset == preset { Image(systemName: "checkmark.circle.fill").foregroundStyle(theme.accent) } }
                            }.padding(12).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                        }.buttonStyle(.plain)
                    }
                }
                Toggle("Color from album artwork", isOn: $theme.useArtworkColors).tint(theme.accent)
                VStack(alignment: .leading, spacing: 10) {
                    Text("Appearance").font(.headline)
                    Picker("Appearance", selection: $theme.appearance) { Text("Dark").tag("Dark"); Text("Light").tag("Light"); Text("Auto").tag("Auto") }.pickerStyle(.segmented)
                }
                Toggle("Reduce motion", isOn: $theme.reduceMotion).tint(theme.accent)
            }.padding(22)
        }.foregroundStyle(.white)
    }
}

struct MiniPlayer: View {
    @Environment(PlayerEngine.self) private var engine
    var open: () -> Void
    var body: some View {
        HStack(spacing: 12) {
            Button(action: open) {
                HStack(spacing: 10) {
                    if let track = engine.currentTrack { ArtworkView(track: track).frame(width: 46, height: 46) }
                    VStack(alignment: .leading, spacing: 3) { Text(engine.currentTrack?.title ?? "Not playing").font(.subheadline.bold()).foregroundStyle(.white).lineLimit(1); Text(engine.currentTrack?.artist ?? "").font(.caption).foregroundStyle(Theme.muted).lineLimit(1) }
                }
            }.buttonStyle(.plain)
            Spacer(minLength: 0)
            Image(systemName: engine.isPlaying ? "waveform" : "waveform").foregroundStyle(ThemeAccent.color)
            Button { engine.togglePlayPause() } label: { Image(systemName: engine.isPlaying ? "pause.fill" : "play.fill").font(.title3).foregroundStyle(.white).frame(width: 42, height: 44) }.buttonStyle(.plain)
        }.padding(9).background(Theme.card, in: Capsule())
    }
}
